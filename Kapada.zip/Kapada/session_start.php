<?php
include ('config.php');
session_start();    
?>
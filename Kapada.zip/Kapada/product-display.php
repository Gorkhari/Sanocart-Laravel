<?php
?>
<!DOCTYPE html>
<html>
	<head>
		<div class="content">
			<h2>Your Products List</h2>
			<div>
				<p>Your Products details are below:</p>

				<div class="add-item-button">
				<a href="be_interface.php"><button class="add-new-ittem-button" type="button">Add New Items</button></a>
</div>


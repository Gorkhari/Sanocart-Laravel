<html>

<head>
    <link href="style.css" rel="stylesheet" type="text/css">
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.7.1/css/all.css">
</head>
<div class="main-wide-container">
    <div class="footer">
        <div class="end_box">
            <div class="small_end_box">
                <h1>Customer Service</h1>
            </div>
            <div class="left-right-footer">
                <div class="left-footer">
                    <div class="left-footer-container">
                        <h2 class="left-footer-heading">Contact Us</h2>
                        <ul class="left-footer-list-items">
                            <li class="left-icon-list-item">
                                <span class="left-footer-list-text">Viber :</span> +61 000000000</span>
                                </a>
                            </li>
                            <li class="left-footer-icon-list-item">
                                <span class="left-footer-icon-list-text">Email:</span> Supports@Kapada.com</span>
                                </a>
                            </li>
                            <li class="left-icon-list-item">
                                <span class="left-icon-list-text">Phone:</span> +61 000000000</span>
                                </a>
                            </li>
                            <li class="left-icon-list-item">
                                <span class="left-icon-list-text">Address:</span>545 Kent St, Haymarket NSW 2000</span>
                            </li>
                        </ul>
                    </div>
                </div>
                <div class="right-footer">
                    <div class="right-footer-container">
                        <h2 class="right-footer-heading">Learn More!
                            <h2>
                                <ul class="right-footer-item">
                                    <li class="right-icon-item-list">
                                        <span class="right-footer-list-text">
                                            </spam>
                                    </li>
                                </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

</html>
<div class="nav-bar">
    <div class="menu_bar">
        <menu>Shop By Categories</menu>
        <div class="dropdown-content">
            <div class="sub-dropdown-content-first-column">
                <div class="sub-dropdown-content">
                    <div class="zoom">
                        <a href="women_cate.php"><img src="Images/women.jpg" style="width:150px;height:200px;"></a>
                    </div>
                </div>
            </div>
            <div class="sub-dropdown-content-secound-column">
                <div class="sub-dropdown-content">
                    <div class="zoom">
                        <a href="men_cate.php"><img src="Images/men.jpg" style="width:150px;height:200px;"></a>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="menu_bar"><a href="single-product-details.php">
            <menu>Clearance Sale</menu>
        </a>
    </div>
    <div class="menu_bar"><a href="aboutus.php">
            <menu>About Us</menu>
        </a>
    </div>
    <div class="menu_bar"><a href="contactus.php">
            <menu>Contact Us</menu>
        </a>
    </div>
</div>
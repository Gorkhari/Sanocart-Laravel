<?php
require $_SERVER['DOCUMENT_ROOT'] . '/kapada/config.php';
include $_SERVER['DOCUMENT_ROOT'] . '/kapada/call/be_inferface_call.php';
include $_SERVER['DOCUMENT_ROOT'] . '/kapada/main_header.php';
include $_SERVER['DOCUMENT_ROOT'] . '/kapada/call/admin_detail_call.php';
?>
<?php
if (!isset($row_Products['admin_id'])) {
  header('Location: index.php');
  exit;
}
?>
<?php
if (!function_exists("GetSQLValueString")) {
  function GetSQLValueString($theValue, $theType, $theDefinedValue = "", $theNotDefinedValue = "")
  {
    switch ($theType) {
      case "text":
        $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
        break;
      case "long":
      case "int":
        $theValue = ($theValue != "") ? intval($theValue) : "NULL";
        break;
      case "double":
        $theValue = ($theValue != "") ? "'" . doubleval($theValue) . "'" : "NULL";
        break;
      case "date":
        $theValue = ($theValue != "") ? "'" . $theValue . "'" : "NULL";
        break;
      case "defined":
        $theValue = ($theValue != "") ? $theDefinedValue : $theNotDefinedValue;
        break;
    }
    return $theValue;
  }
}

if ((isset($_GET['product_id'])) && ($_GET['product_id'] != "")) {
  $deleteSQL = sprintf(
    "DELETE FROM product WHERE product_id=%s",
    GetSQLValueString($_GET['product_id'], "int")
  );

  mysqli_select_db($con, 'temp');
  $Result1 = mysqli_query($con, $deleteSQL) or die(mysqli_error($con));

  $deleteGoTo = "../admin/be_interface.php";
  if (isset($_SERVER['QUERY_STRING'])) {
    $deleteGoTo .= (strpos($deleteGoTo, '?')) ? "&" : "?";
    $deleteGoTo .= $_SERVER['QUERY_STRING'];
  }
  header("Location: ../admin/be_interface.php");
}
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">

<head>
  <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
  <title>Delete Page</title>
  <link href="be_filestyle.css" rel="stylesheet" type="text/css" />
</head>

<body>
  <p align="center" class="pageTitle">Delete Page</p>
  <p>This page delete a Product </p>
  <p>&nbsp;</p>
</body>

</html>
<?php
include ('session_start.php');
if (!isset($_SESSION['loggedin']) ){ 
  include ('headers/header.php');
}
  else {
    include ('headers/header_2.php');
  }
  ?>
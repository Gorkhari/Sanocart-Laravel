<?php
include ('config.php');
?>
<?php
if (!isset($_SESSION)) {
	session_start();
  }
?>
<?php
if (!isset($_SESSION['loggedin']) ){ 
  include ('headers/header.php');
}
  else {
    include ('headers/header_2.php');
  }
  ?>

<head>
    <link href='CSS\style.css' rel="stylesheet" type="text/css">
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.7.1/css/all.css">
</head>
<div class="main-body-container">
    <div class="main-wide-container">
        <!-- Add The Information below  -->












        <!-- dont edit any thing -->
    </div>
</div>
</div>
<?php
include ('footers/footer.php');
?>